from django.apps import AppConfig


class HousemaidConfig(AppConfig):
    name = 'housemaid'
